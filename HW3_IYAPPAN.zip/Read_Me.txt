

	*** READ ME ***

1. Download and import all required files	
2. Open the code Adaboost[new].ipynb in jupyter notebook or Adaboost_submission.py (attached both formats) and run each code segment in the same order.
3. Check the rounds loops with different values for number of classifiers as mentioned.
4. Have included comments for print statements & for furthur understanding inside loops to check values.
5. I stored all files in jupyter notebook hence can directly access it in the program. 
(If downloading it somewhere else, have to change the file path in the program.)
